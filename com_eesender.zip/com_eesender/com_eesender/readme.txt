Author:        ElasticEmail
Date:          2019-04-10
Copyright:     Copyright (C) 2010-2014 elasticemail.com . All rights reserved.
License:       GNU General Public License version 2 or later; see LICENSE
Version:       0.9.0
Compatibility: Joomla 2.5.X, Joomla 3.X

Install guide
1. Download the extension "com_eesender.zip" to your local machine.
2. From the administrator dashboard of your Joomla site  select Extensions -> Install
3. Click the Browse button and select the extension package on your local machine.
4. Click the Upload File & Install button.


Note: First you need to configure the component. Go to component and click on Elastic Email item, then please find and clicked in the upper-right corner on "option" ico. 
Complete the required fields with your API key.
After setting the api-key and user name for component, in the screen you should see the Elastic Email Sender .
You can also go directly to the Elastic Email Sender Component and provide valid API key to your Elastic Email Account there. After validation, you should see the component, and the plugin should be activated by itself.
If not please see In Extensions -> Manage if Elasti Email plugin is activated. 